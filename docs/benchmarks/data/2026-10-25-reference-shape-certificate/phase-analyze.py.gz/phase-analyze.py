import json,pathlib,sys,re
r=pathlib.Path(sys.argv[1]); log=pathlib.Path(sys.argv[2]).read_text(encoding='utf-8-sig')
phase_names=['lower','candidate','format','classify_manifest','history','canonical_envelope','certificate','json','ron','json_encode','json_preflight','ron_encode','ron_preflight']
rows=[json.loads(line.split('NARA_PREPARATION_PHASE_ROW ',1)[1]) for line in log.splitlines() if 'NARA_PREPARATION_PHASE_ROW ' in line]
public=[]
for line in log.splitlines():
    if 'NARA_PREPARATION_PUBLIC_ROW ' in line:
        m=re.search(r'kind=(\w+) extra_entities=(\d+) mode=(\w+) prepare_ns=(\[[^\]]+\])',line)
        public.append({'kind':m[1],'entities':int(m[2])+1,'mode':m[3],'prepare_ns':json.loads(m[4])})
assert len(rows)==576,len(rows)
assert len(public)==8,len(public)
expected_cases=[(kind,entities,mode) for kind in ['Scene','Prefab'] for entities in [1,257] for mode in ['Direct','Panel']]
assert [(case['kind'],case['entities'],case['mode']) for case in public]==expected_cases
assert [row['sequence'] for row in rows]==list(range(1,577))
def q(xs,p):return sorted(xs)[(len(xs)*p+99)//100-1]
results=[]
for i,case in enumerate(public):
    block=rows[i*72:(i+1)*72]
    assert len(case['prepare_ns'])==64
    assert all(row['kind']==case['kind'] and row['entities']==case['entities'] for row in block)
    samples=block[8:]
    totals=case['prepare_ns']
    for row,total in zip(samples,totals):
        assert len(row['phases_ns'])==13
        assert row['certified'] is not None and row['local_classification'] is not None
        assert sum(row['phases_ns'][:5])<=row['total_ns']<=total,(row,total)
        phase=row['phases_ns']
        assert phase[5]+phase[6]+phase[7]+phase[8]<=phase[2]
        assert phase[9]+phase[10]<=phase[7]
        assert phase[11]+phase[12]<=phase[8]
    metrics={name:{'p50_ns':q([row['phases_ns'][j] for row in samples],50),'p95_ns':q([row['phases_ns'][j] for row in samples],95)} for j,name in enumerate(phase_names)}
    result={'kind':case['kind'],'entities':case['entities'],'mode':case['mode'],'public_p50_ns':q(totals,50),'public_p95_ns':q(totals,95),'phase_quantiles':metrics,'format_share_p50':q([row['phases_ns'][2]/t for row,t in zip(samples,totals)],50),'covered_share_p50':q([sum(row['phases_ns'][:5])/t for row,t in zip(samples,totals)],50),'min_covered_share':min(sum(row['phases_ns'][:5])/t for row,t in zip(samples,totals)),'outside_scene_share_p50':q([(t-row['total_ns'])/t for row,t in zip(samples,totals)],50),'certificate_true':sum(row['certified'] for row in samples),'local_true':sum(row['local_classification'] for row in samples),'samples':samples,'public_prepare_ns':totals}
    results.append(result)
    result['covered_share_total']=sum(sum(row['phases_ns'][:5]) for row in samples)/sum(totals)
    result['phase_share_p50']={name:q([row['phases_ns'][j]/total for row,total in zip(samples,totals)],50) for j,name in enumerate(phase_names)}
output={'run_id':re.search(r'Nextest run ID ([\w-]+)',log)[1],'phase_names':phase_names,'rows_including_warmups':rows,'cases':results}
p=r/(sys.argv[3]+'.json');p.write_text(json.dumps(output,indent=2),encoding='utf-8')
assert json.loads(p.read_text())['run_id']==output['run_id']
for c in results:
    print(c['kind'],c['entities'],c['mode'],'public_ms',round(c['public_p50_ns']/1e6,4),'format%',round(c['format_share_p50']*100,2),'covered%',round(c['covered_share_p50']*100,2),'cert/local',c['certificate_true'],c['local_true'])
