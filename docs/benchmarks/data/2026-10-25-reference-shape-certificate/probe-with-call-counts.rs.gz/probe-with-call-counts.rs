//! Temporary decision-local instrumentation; removed after phase attribution.

use std::{cell::RefCell, time::Instant};

#[derive(Clone, Copy)]
pub(crate) enum Phase {
    Lower,
    Candidate,
    Format,
    ClassifyManifest,
    History,
    CanonicalEnvelope,
    Certificate,
    Json,
    Ron,
    JsonEncode,
    JsonPreflight,
    RonEncode,
    RonPreflight,
}

struct Row {
    kind: &'static str,
    entities: usize,
    total_ns: u128,
    phases_ns: [u128; 13],
    phase_calls: [u32; 13],
    certified: Option<bool>,
    local_classification: Option<bool>,
}

struct State {
    enabled: bool,
    active: Option<Row>,
    rows: Vec<Row>,
}

impl State {
    fn new() -> Self {
        Self {
            enabled: std::env::var_os("NARA_PREPARATION_PHASES").as_deref()
                == Some(std::ffi::OsStr::new("1")),
            active: None,
            rows: Vec::with_capacity(1024),
        }
    }
}

impl Drop for State {
    fn drop(&mut self) {
        for (index, row) in self.rows.iter().enumerate() {
            let flag = |value| match value {
                Some(true) => "true",
                Some(false) => "false",
                None => "null",
            };
            println!(
                "NARA_PREPARATION_PHASE_ROW {{\"sequence\":{},\"kind\":\"{}\",\"entities\":{},\"total_ns\":{},\"phases_ns\":{:?},\"phase_calls\":{:?},\"certified\":{},\"local_classification\":{}}}",
                index + 1,
                row.kind,
                row.entities,
                row.total_ns,
                row.phases_ns,
                row.phase_calls,
                flag(row.certified),
                flag(row.local_classification),
            );
        }
    }
}

thread_local! {
    static STATE: RefCell<State> = RefCell::new(State::new());
}

pub(crate) struct Root(Option<Instant>);

pub(crate) fn enter(kind: &'static str, entities: usize) -> Root {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if !state.enabled {
            return Root(None);
        }
        assert!(
            state.active.is_none(),
            "unexpected nested property preparation"
        );
        state.active = Some(Row {
            kind,
            entities,
            total_ns: 0,
            phases_ns: [0; 13],
            phase_calls: [0; 13],
            certified: None,
            local_classification: None,
        });
        Root(Some(Instant::now()))
    })
}

impl Drop for Root {
    fn drop(&mut self) {
        let Some(started) = self.0 else { return };
        let elapsed = started.elapsed().as_nanos();
        STATE.with(|state| {
            let mut state = state.borrow_mut();
            let mut row = state.active.take().expect("matching property preparation");
            row.total_ns = elapsed;
            state.rows.push(row);
        });
    }
}

pub(crate) struct Span {
    phase: Phase,
    started: Option<Instant>,
}

pub(crate) fn span(phase: Phase) -> Span {
    Span {
        phase,
        started: STATE.with(|state| {
            state.borrow_mut().active.as_mut().map(|row| {
                row.phase_calls[phase as usize] += 1;
                Instant::now()
            })
        }),
    }
}

impl Drop for Span {
    fn drop(&mut self) {
        let Some(started) = self.started else { return };
        let elapsed = started.elapsed().as_nanos();
        STATE.with(|state| {
            if let Some(row) = &mut state.borrow_mut().active {
                row.phases_ns[self.phase as usize] += elapsed;
            }
        });
    }
}

pub(crate) fn certificate(value: bool) {
    STATE.with(|state| {
        if let Some(row) = &mut state.borrow_mut().active {
            assert!(row.certified.replace(value).is_none());
        }
    });
}

pub(crate) fn classification(local: bool) {
    STATE.with(|state| {
        if let Some(row) = &mut state.borrow_mut().active {
            assert!(row.local_classification.replace(local).is_none());
        }
    });
}
